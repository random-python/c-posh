/* LockObject.h */

#ifndef LOCKOBJECT_H_INCLUDED
#define LOCKOBJECT_H_INCLUDED

#include "_core.h"

extern PyTypeObject Lock_Type;

#endif
