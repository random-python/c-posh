/* Monitor.h */

#ifndef MONITOR_H_INCLUDED
#define MONITOR_H_INCLUDED

#include "_core.h"

extern PyTypeObject Monitor_Type;

#endif
