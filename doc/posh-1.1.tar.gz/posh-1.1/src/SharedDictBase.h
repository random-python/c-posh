/* SharedDictBase.h */

#ifndef SHAREDDICTBASE_H_INCLUDED
#define SHAREDDICTBASE_H_INCLUDED

#include "_core.h"

extern PyTypeObject SharedDictBase_Type;

#endif
